export type PayMethod = "cash" | "credit";
export type PriceMethod = "markup" | "margin";

export type Product = {
  id: string;
  name: string;
  category: string;
  sku: string;
  barcode: string;
  cost: number;
  qty: number;
  reorder: number;
  supplier: string;
  method: PriceMethod;
  percent: number;
  price: number;
};

export type Sale = {
  id: string;
  date: string;
  productId: string;
  productName: string;
  qty: number;
  unitPrice: number;
  discount: number;
  total: number;
  costAtSale: number;
  profit: number;
  note: string;
  payMethod: PayMethod;
  customer: string;
};

export type CreditPayment = { date: string; amount: number; note: string };

export type Credit = {
  id: string;
  customer: string;
  phone: string;
  limit: number;
  amount: number;
  paid: number;
  date: string;
  due: string;
  note: string;
  payments: CreditPayment[];
  saleId?: string;
};

export type Settings = { storeName: string; subtitle: string };

export type StoreData = {
  products: Product[];
  sales: Sale[];
  credits: Credit[];
  settings: Settings;
};

export const STORAGE_KEY = "kareth-store-v2";
export const FILE_KIND = "kareth-store-backup";

export const CATEGORIES = [
  "Hardware",
  "Convenience",
  "Food & Beverage",
  "Cleaning",
  "Electrical",
  "Plumbing",
  "Tools",
  "Other",
];

export function emptyStore(): StoreData {
  return {
    products: [],
    sales: [],
    credits: [],
    settings: {
      storeName: "Kareth Trading & Manufacturing Co.",
      subtitle: "Convenience store · works offline after install",
    },
  };
}

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export function peso(n: number) {
  const v = Number.isFinite(n) ? n : 0;
  return `₱${v.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function sellingPrice(cost: number, percent: number, method: PriceMethod) {
  const c = Math.max(0, cost);
  const p = Math.max(0, percent);
  if (method === "margin") {
    const m = Math.min(p, 99.99) / 100;
    return c / (1 - m);
  }
  return c * (1 + p / 100);
}

export function isoToday() {
  const d = new Date();
  const z = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

export function plusDays(date: string, days: number) {
  const d = new Date(`${date || isoToday()}T12:00:00`);
  d.setDate(d.getDate() + days);
  const z = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

export function dateLabel(iso: string) {
  if (!iso) return "—";
  const d = new Date(iso.length <= 10 ? `${iso}T12:00:00` : iso);
  return d.toLocaleString("en-PH", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: iso.length > 10 ? "numeric" : undefined,
    minute: iso.length > 10 ? "2-digit" : undefined,
  });
}

export function creditBalance(c: Credit) {
  return Math.max(0, Number(c.amount || 0) - Number(c.paid || 0));
}

export function creditStatus(c: Credit) {
  const b = creditBalance(c);
  if (b <= 0) return "PAID";
  if (c.due < isoToday()) return "OVERDUE";
  if (c.due <= plusDays(isoToday(), 2)) return "DUE SOON";
  return "UNPAID";
}

export function loadStore(): StoreData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyStore();
    const parsed = JSON.parse(raw) as StoreData;
    return {
      products: Array.isArray(parsed.products) ? parsed.products : [],
      sales: Array.isArray(parsed.sales) ? parsed.sales : [],
      credits: Array.isArray(parsed.credits) ? parsed.credits : [],
      settings: { ...emptyStore().settings, ...(parsed.settings || {}) },
    };
  } catch {
    return emptyStore();
  }
}

export function saveStore(data: StoreData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function backupPayload(data: StoreData) {
  return {
    kind: FILE_KIND,
    version: 2,
    exportedAt: new Date().toISOString(),
    ...data,
  };
}

export function parseBackup(text: string): StoreData {
  const parsed = JSON.parse(text) as Partial<StoreData> & { kind?: string };
  if (!parsed || typeof parsed !== "object") throw new Error("Not a store file.");
  if (!Array.isArray(parsed.products) || !Array.isArray(parsed.sales)) {
    throw new Error("This file is not a Kareth store backup.");
  }
  return {
    products: parsed.products,
    sales: parsed.sales,
    credits: Array.isArray(parsed.credits) ? parsed.credits : [],
    settings: { ...emptyStore().settings, ...(parsed.settings || {}) },
  };
}

export function downloadBackup(data: StoreData) {
  const blob = new Blob([JSON.stringify(backupPayload(data), null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  const name = `Kareth-Store-${isoToday()}.json`;
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  return name;
}

const HANDLE_DB = "kareth-desktop";
const HANDLE_KEY = "current";

type WritableHandle = FileSystemFileHandle & {
  queryPermission?: (d: { mode: "readwrite" }) => Promise<PermissionState>;
  requestPermission?: (d: { mode: "readwrite" }) => Promise<PermissionState>;
};

function openHandleDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(HANDLE_DB, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore("handles");
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export function canPickFiles() {
  return typeof window !== "undefined" && "showSaveFilePicker" in window;
}

export async function rememberedFile(): Promise<FileSystemFileHandle | null> {
  try {
    const db = await openHandleDb();
    const handle = await new Promise<FileSystemFileHandle | undefined>((resolve, reject) => {
      const tx = db.transaction("handles", "readonly");
      const req = tx.objectStore("handles").get(HANDLE_KEY);
      req.onsuccess = () => resolve(req.result as FileSystemFileHandle | undefined);
      req.onerror = () => reject(req.error);
    });
    return handle ?? null;
  } catch {
    return null;
  }
}

async function rememberFile(handle: FileSystemFileHandle) {
  const db = await openHandleDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction("handles", "readwrite");
    tx.objectStore("handles").put(handle, HANDLE_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function ensureWrite(handle: FileSystemFileHandle) {
  const h = handle as WritableHandle;
  const q = await h.queryPermission?.({ mode: "readwrite" });
  if (q === "granted") return;
  const r = await h.requestPermission?.({ mode: "readwrite" });
  if (r && r !== "granted") throw new Error("Allow the app to save this file, then try again.");
}

export async function writeStoreFile(handle: FileSystemFileHandle, data: StoreData) {
  await ensureWrite(handle);
  const writable = await handle.createWritable();
  await writable.write(JSON.stringify(backupPayload(data), null, 2));
  await writable.close();
  await rememberFile(handle);
}

export async function saveAsStoreFile(data: StoreData): Promise<{ name: string; handle: FileSystemFileHandle | null }> {
  if (!canPickFiles()) {
    return { name: downloadBackup(data), handle: null };
  }
  const picker = (window as unknown as { showSaveFilePicker: (o: unknown) => Promise<FileSystemFileHandle> }).showSaveFilePicker;
  const handle = await picker({
    suggestedName: `Kareth-Store-${isoToday()}.json`,
    types: [{ description: "Kareth store file", accept: { "application/json": [".json"] } }],
  });
  await writeStoreFile(handle, data);
  return { name: handle.name, handle };
}

export async function openStoreFile(): Promise<{ data: StoreData; name: string; handle: FileSystemFileHandle | null }> {
  if (canPickFiles()) {
    const picker = (window as unknown as { showOpenFilePicker: (o: unknown) => Promise<FileSystemFileHandle[]> }).showOpenFilePicker;
    const [handle] = await picker({
      types: [{ description: "Kareth store file", accept: { "application/json": [".json"] } }],
      multiple: false,
    });
    const file = await handle.getFile();
    const data = parseBackup(await file.text());
    await rememberFile(handle);
    return { data, name: handle.name, handle };
  }
  const file = await new Promise<File | null>((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json,.json";
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.click();
  });
  if (!file) throw new Error("No file chosen.");
  const data = parseBackup(await file.text());
  return { data, name: file.name, handle: null };
}
