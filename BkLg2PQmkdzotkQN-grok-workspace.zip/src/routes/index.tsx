import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Calculator,
  ClipboardList,
  Download,
  FolderOpen,
  LayoutDashboard,
  MonitorDown,
  Package,
  Receipt,
  Settings2,
  Trash2,
  Wallet,
} from "lucide-react";
import {
  CATEGORIES,
  type Credit,
  type PayMethod,
  type PriceMethod,
  type Product,
  type Sale,
  type StoreData,
  creditBalance,
  creditStatus,
  dateLabel,
  emptyStore,
  isoToday,
  loadStore,
  openStoreFile,
  peso,
  plusDays,
  rememberedFile,
  saveAsStoreFile,
  saveStore,
  sellingPrice,
  uid,
  writeStoreFile,
} from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

type Tab = "dashboard" | "products" | "pricing" | "sales" | "credit" | "backup";

const TABS: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "products", label: "Products", icon: Package },
  { id: "pricing", label: "Price", icon: Calculator },
  { id: "sales", label: "Sales", icon: Receipt },
  { id: "credit", label: "Credit", icon: Wallet },
  { id: "backup", label: "Save & Install", icon: MonitorDown },
];

function Home() {
  const [ready, setReady] = useState(false);
  const [data, setData] = useState<StoreData>(emptyStore);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [toast, setToast] = useState("");
  const [installEvt, setInstallEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const fileHandle = useRef<FileSystemFileHandle | null>(null);
  const [menu, setMenu] = useState(false);
  const dataRef = useRef(data);
  dataRef.current = data;

  useEffect(() => {
    setData(loadStore());
    setReady(true);
    rememberedFile().then((handle) => {
      if (handle) {
        fileHandle.current = handle;
        setFileName(handle.name);
      }
    });
  }, []);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  function commit(next: StoreData, message?: string) {
    setData(next);
    saveStore(next);
    if (message) flash(message);
  }

  async function saveCurrent(asNew: boolean) {
    try {
      if (!asNew && fileHandle.current) {
        await writeStoreFile(fileHandle.current, dataRef.current);
        flash(`Saved ${fileHandle.current.name}`);
        return;
      }
      const result = await saveAsStoreFile(dataRef.current);
      if (result.handle) {
        fileHandle.current = result.handle;
        setFileName(result.handle.name);
      }
      flash(result.handle ? `Saved as ${result.name}` : `Downloaded ${result.name}`);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      flash(err instanceof Error ? err.message : "Could not save the file.");
    }
  }

  async function openCurrent() {
    try {
      const result = await openStoreFile();
      fileHandle.current = result.handle;
      setFileName(result.name);
      commit(result.data, `Opened ${result.name}`);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      flash(err instanceof Error ? err.message : "Could not open that file.");
    }
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
      const key = e.key.toLowerCase();
      if (key === "s") {
        e.preventDefault();
        void saveCurrent(e.shiftKey);
      } else if (key === "o") {
        e.preventDefault();
        void openCurrent();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function flash(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  }

  if (!ready) {
    return (
      <main className="grid min-h-screen place-items-center bg-bg text-muted">
        Opening Kareth Store…
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-bg text-ink">
      <div className="sticky top-0 z-30 border-b border-white/10 bg-[#0c241e] text-white">
        <div className="mx-auto flex max-w-5xl items-center gap-1 px-2 py-1 text-sm">
          <img src="/logo-header.png" alt="" width={22} height={22} className="mr-1 rounded bg-white" />
          <span className="mr-2 hidden font-semibold sm:inline">Kareth Store</span>
          <div className="relative">
            <button type="button" className="rounded px-2 py-1 hover:bg-white/10" onClick={() => setMenu((v) => !v)}>
              File
            </button>
            {menu ? (
              <div className="absolute left-0 top-full z-40 mt-1 w-56 rounded-lg border border-line bg-white py-1 text-ink shadow-lg" onMouseLeave={() => setMenu(false)}>
                <button type="button" className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-soft" onClick={() => { setMenu(false); void saveCurrent(false); }}>
                  Save <span className="text-xs text-muted">Ctrl+S</span>
                </button>
                <button type="button" className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-soft" onClick={() => { setMenu(false); void saveCurrent(true); }}>
                  Save as… <span className="text-xs text-muted">Ctrl+Shift+S</span>
                </button>
                <button type="button" className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-soft" onClick={() => { setMenu(false); void openCurrent(); }}>
                  Open… <span className="text-xs text-muted">Ctrl+O</span>
                </button>
              </div>
            ) : null}
          </div>
          <button type="button" className="rounded px-2 py-1 hover:bg-white/10" onClick={() => setTab("backup")}>
            Install
          </button>
          <span className="ml-auto truncate pl-2 text-xs text-white/70">{fileName ? fileName : "Not linked to a file yet"}</span>
        </div>
      </div>
      <header className="sticky top-[37px] z-20 bg-brand text-white shadow-md">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <img src="/logo-header.png" alt="" width={40} height={40} className="rounded-lg bg-white" />
          <div className="min-w-0">
            <h1 className="truncate text-lg font-bold leading-tight">{data.settings.storeName}</h1>
            <p className="truncate text-xs text-white/80">{data.settings.subtitle}</p>
          </div>
        </div>
      </header>
      <nav className="sticky top-[101px] z-10 flex gap-2 overflow-x-auto border-b border-line bg-surface px-3 py-2">
        {TABS.map((t) => {
          const Icon = t.icon;
          const on = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`inline-flex min-h-11 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-sm font-semibold ${
                on ? "bg-brand text-white" : "bg-soft text-brand"
              }`}
            >
              <Icon size={16} />
              {t.label}
            </button>
          );
        })}
      </nav>
      <main className="mx-auto max-w-5xl px-4 py-4 pb-16">
        {tab === "dashboard" && <Dashboard data={data} go={setTab} />}
        {tab === "products" && <Products data={data} commit={commit} />}
        {tab === "pricing" && <Pricing />}
        {tab === "sales" && <Sales data={data} commit={commit} />}
        {tab === "credit" && <CreditPanel data={data} commit={commit} />}
        {tab === "backup" && (
          <Backup
            data={data}
            commit={commit}
            flash={flash}
            installEvt={installEvt}
            clearInstall={() => setInstallEvt(null)}
            fileName={fileName}
            onSave={() => saveCurrent(false)}
            onSaveAs={() => saveCurrent(true)}
            onOpen={openCurrent}
          />
        )}
      </main>
      {toast ? (
        <div className="fixed bottom-4 left-1/2 z-30 max-w-[90vw] -translate-x-1/2 rounded-xl bg-ink px-4 py-2.5 text-sm text-white shadow-lg">
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function Card({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section className="mb-3 rounded-2xl border border-line bg-surface p-4 shadow-sm">
      <h2 className="mb-1 text-lg font-bold">{title}</h2>
      {hint ? <p className="mb-3 text-sm leading-relaxed text-muted">{hint}</p> : null}
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mb-2 block text-xs font-semibold text-muted">
      {label}
      <div className="mt-1 text-ink">{children}</div>
    </label>
  );
}

const inputCls =
  "w-full min-h-11 rounded-lg border border-line bg-white px-3 text-sm text-ink outline-none focus:border-brand-2";

function Dashboard({ data, go }: { data: StoreData; go: (t: Tab) => void }) {
  const today = isoToday();
  const salesToday = data.sales.filter((s) => s.date.slice(0, 10) === today);
  const units = data.products.reduce((a, p) => a + p.qty, 0);
  const value = data.products.reduce((a, p) => a + p.qty * p.cost, 0);
  const sold = salesToday.reduce((a, s) => a + s.total, 0);
  const low = data.products.filter((p) => p.qty <= p.reorder);
  return (
    <>
      <Card title="Store overview">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <Stat label="Products" value={String(data.products.length)} />
          <Stat label="Units in stock" value={String(units)} />
          <Stat label="Inventory cost" value={peso(value)} />
          <Stat label="Sales today" value={peso(sold)} />
        </div>
      </Card>
      <Card title="Low stock" hint="Items at or below their reorder point.">
        {low.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted">Nothing is low. Add products to start tracking.</p>
        ) : (
          <ul className="divide-y divide-line text-sm">
            {low.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-2">
                <span className="font-semibold">{p.name}</span>
                <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-bold text-warn">
                  {p.qty} left
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="min-h-11 rounded-lg bg-brand px-4 font-bold text-white" onClick={() => go("products")}>
          Add product
        </button>
        <button type="button" className="min-h-11 rounded-lg bg-soft px-4 font-bold text-brand" onClick={() => go("sales")}>
          Record sale
        </button>
        <button type="button" className="min-h-11 rounded-lg bg-soft px-4 font-bold text-brand" onClick={() => go("backup")}>
          Save a copy
        </button>
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-soft p-3">
      <span className="block text-xs text-muted">{label}</span>
      <strong className="mt-1 block break-words text-lg">{value}</strong>
    </div>
  );
}

function Products({ data, commit }: { data: StoreData; commit: (d: StoreData, m?: string) => void }) {
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [sku, setSku] = useState("");
  const [barcode, setBarcode] = useState("");
  const [cost, setCost] = useState("");
  const [qty, setQty] = useState("");
  const [reorder, setReorder] = useState("5");
  const [supplier, setSupplier] = useState("");
  const [method, setMethod] = useState<PriceMethod>("markup");
  const [percent, setPercent] = useState("25");
  const [query, setQuery] = useState("");

  const price = sellingPrice(Number(cost) || 0, Number(percent) || 0, method);

  function reset() {
    setEditId(null);
    setName("");
    setSku("");
    setBarcode("");
    setCost("");
    setQty("");
    setReorder("5");
    setSupplier("");
    setMethod("markup");
    setPercent("25");
    setCategory(CATEGORIES[0]);
  }

  function edit(p: Product) {
    setEditId(p.id);
    setName(p.name);
    setCategory(p.category);
    setSku(p.sku);
    setBarcode(p.barcode);
    setCost(String(p.cost));
    setQty(String(p.qty));
    setReorder(String(p.reorder));
    setSupplier(p.supplier);
    setMethod(p.method);
    setPercent(String(p.percent));
  }

  function save() {
    if (!name.trim()) return;
    const product: Product = {
      id: editId || uid(),
      name: name.trim(),
      category,
      sku: sku.trim(),
      barcode: barcode.trim(),
      cost: Math.max(0, Number(cost) || 0),
      qty: Math.max(0, Math.floor(Number(qty) || 0)),
      reorder: Math.max(0, Math.floor(Number(reorder) || 0)),
      supplier: supplier.trim(),
      method,
      percent: Math.min(99.99, Math.max(0, Number(percent) || 0)),
      price: Math.round(price * 100) / 100,
    };
    const products = editId
      ? data.products.map((p) => (p.id === editId ? product : p))
      : [product, ...data.products];
    commit({ ...data, products }, editId ? "Product updated" : "Product saved");
    reset();
  }

  const rows = data.products.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return [p.name, p.sku, p.barcode, p.category].join(" ").toLowerCase().includes(q);
  });

  return (
    <>
      <Card title={editId ? "Edit product" : "Add product"}>
        <div className="grid gap-x-3 md:grid-cols-2">
          <Field label="Product name *">
            <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. 1/2-inch PVC elbow" />
          </Field>
          <Field label="Category">
            <select className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </Field>
          <Field label="SKU">
            <input className={inputCls} value={sku} onChange={(e) => setSku(e.target.value)} />
          </Field>
          <Field label="Barcode">
            <input className={inputCls} value={barcode} onChange={(e) => setBarcode(e.target.value)} inputMode="numeric" />
          </Field>
          <Field label="Unit cost (₱) *">
            <input className={inputCls} type="number" min="0" step="0.01" value={cost} onChange={(e) => setCost(e.target.value)} />
          </Field>
          <Field label="Stock *">
            <input className={inputCls} type="number" min="0" step="1" value={qty} onChange={(e) => setQty(e.target.value)} />
          </Field>
          <Field label="Low-stock threshold">
            <input className={inputCls} type="number" min="0" step="1" value={reorder} onChange={(e) => setReorder(e.target.value)} />
          </Field>
          <Field label="Supplier">
            <input className={inputCls} value={supplier} onChange={(e) => setSupplier(e.target.value)} />
          </Field>
        </div>
        <div className="grid gap-x-3 md:grid-cols-2">
          <Field label="Pricing method">
            <select className={inputCls} value={method} onChange={(e) => setMethod(e.target.value as PriceMethod)}>
              <option value="markup">Markup on cost</option>
              <option value="margin">Target profit margin</option>
            </select>
          </Field>
          <Field label="Percentage (%)">
            <input className={inputCls} type="number" min="0" max="99.99" step="0.1" value={percent} onChange={(e) => setPercent(e.target.value)} />
          </Field>
        </div>
        <div className="mt-2 rounded-xl border border-line bg-soft p-3">
          <span className="text-xs text-muted">Suggested selling price</span>
          <strong className="block text-xl text-brand">{peso(price)}</strong>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className="min-h-11 rounded-lg bg-brand px-4 font-bold text-white" onClick={save}>
            Save product
          </button>
          <button type="button" className="min-h-11 rounded-lg bg-soft px-4 font-bold text-brand" onClick={reset}>
            Clear
          </button>
        </div>
      </Card>
      <Card title="Product list">
        <input className={`${inputCls} mb-3`} placeholder="Search name, SKU, or barcode" value={query} onChange={(e) => setQuery(e.target.value)} />
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-muted">
              <tr>
                <th className="py-2">Product</th>
                <th>Cost</th>
                <th>Price</th>
                <th>Stock</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="py-2 pr-2">
                    <div className="font-semibold">{p.name}</div>
                    <div className="text-xs text-muted">{p.category}{p.sku ? ` · ${p.sku}` : ""}</div>
                  </td>
                  <td>{peso(p.cost)}</td>
                  <td>{peso(p.price)}</td>
                  <td>
                    <span className={p.qty <= 0 ? "font-bold text-danger" : p.qty <= p.reorder ? "font-bold text-warn" : ""}>
                      {p.qty}
                    </span>
                  </td>
                  <td className="whitespace-nowrap">
                    <button type="button" className="mr-1 min-h-9 rounded-lg bg-soft px-2 text-xs font-bold text-brand" onClick={() => edit(p)}>
                      Edit
                    </button>
                    <button
                      type="button"
                      className="min-h-9 rounded-lg bg-red-50 px-2 text-xs font-bold text-danger"
                      onClick={() => commit({ ...data, products: data.products.filter((x) => x.id !== p.id) }, "Product removed")}
                    >
                      <Trash2 className="inline" size={14} />
                    </button>
                  </td>
                </tr>
              ))}
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-muted">No products match.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

function Pricing() {
  const [cost, setCost] = useState("100");
  const [percent, setPercent] = useState("25");
  const [method, setMethod] = useState<PriceMethod>("markup");
  const price = sellingPrice(Number(cost) || 0, Number(percent) || 0, method);
  const c = Number(cost) || 0;
  const p = Number(percent) || 0;
  const explain =
    method === "markup"
      ? `Cost ${peso(c)} + ${p}% markup = ${peso(price)}.`
      : `Cost ${peso(c)} at a ${p}% margin = ${peso(price)}.`;
  return (
    <Card title="Price calculator" hint="Markup adds a percent on top of cost. Margin is the share of the selling price that is profit, and must stay under 100%.">
      <Field label="Unit cost (₱)">
        <input className={inputCls} type="number" min="0" step="0.01" value={cost} onChange={(e) => setCost(e.target.value)} />
      </Field>
      <Field label="Percentage (%)">
        <input className={inputCls} type="number" min="0" max="99.99" step="0.1" value={percent} onChange={(e) => setPercent(e.target.value)} />
      </Field>
      <Field label="Method">
        <select className={inputCls} value={method} onChange={(e) => setMethod(e.target.value as PriceMethod)}>
          <option value="markup">Markup on cost</option>
          <option value="margin">Target profit margin</option>
        </select>
      </Field>
      <div className="rounded-xl border border-line bg-soft p-3">
        <span className="text-xs text-muted">Recommended selling price</span>
        <strong className="block text-2xl text-brand">{peso(price)}</strong>
        <p className="mt-1 text-sm text-muted">{explain}</p>
      </div>
    </Card>
  );
}

function Sales({ data, commit }: { data: StoreData; commit: (d: StoreData, m?: string) => void }) {
  const [lookup, setLookup] = useState("");
  const [picked, setPicked] = useState<Product | null>(null);
  const [qty, setQty] = useState("1");
  const [unit, setUnit] = useState("");
  const [discount, setDiscount] = useState("0");
  const [pay, setPay] = useState<PayMethod>("cash");
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");

  const matches = useMemo(() => {
    const q = lookup.trim().toLowerCase();
    if (!q || picked) return [];
    return data.products.filter((p) => [p.name, p.sku, p.barcode].join(" ").toLowerCase().includes(q)).slice(0, 8);
  }, [lookup, data.products, picked]);

  const qn = Math.max(0, Math.floor(Number(qty) || 0));
  const un = Math.max(0, Number(unit) || 0);
  const disc = Math.max(0, Number(discount) || 0);
  const total = Math.max(0, qn * un - disc);
  const profit = picked ? total - qn * picked.cost : 0;

  function choose(p: Product) {
    setPicked(p);
    setUnit(String(p.price));
    setLookup(p.name);
  }

  function complete() {
    if (!picked) return;
    if (!Number.isInteger(qn) || qn < 1 || qn > picked.qty) return;
    if (pay === "credit" && !customer.trim()) return;
    const sale: Sale = {
      id: uid(),
      date: new Date().toISOString(),
      productId: picked.id,
      productName: picked.name,
      qty: qn,
      unitPrice: un,
      discount: disc,
      total,
      costAtSale: picked.cost,
      profit,
      note: note.trim(),
      payMethod: pay,
      customer: pay === "credit" ? customer.trim() : "",
    };
    const products = data.products.map((p) => (p.id === picked.id ? { ...p, qty: p.qty - qn } : p));
    let credits = data.credits;
    if (pay === "credit") {
      const date = isoToday();
      const limit = 2000;
      const owed = data.credits
        .filter((c) => c.customer.toLowerCase() === customer.trim().toLowerCase())
        .reduce((a, c) => a + creditBalance(c), 0);
      if (owed + total > limit) return;
      const credit: Credit = {
        id: uid(),
        customer: customer.trim(),
        phone: phone.trim(),
        limit,
        amount: total,
        paid: 0,
        date,
        due: plusDays(date, 7),
        note: `${qn} × ${picked.name}`,
        payments: [],
        saleId: sale.id,
      };
      credits = [...data.credits, credit];
    }
    commit(
      { ...data, products, sales: [sale, ...data.sales], credits },
      `${pay === "credit" ? "Credit" : "Cash"} sale recorded · ${peso(total)}`,
    );
    setPicked(null);
    setLookup("");
    setQty("1");
    setDiscount("0");
    setNote("");
    setCustomer("");
    setPhone("");
    setPay("cash");
  }

  return (
    <>
      <Card title="Record a sale">
        <Field label="Find product">
          <input className={inputCls} value={lookup} placeholder="Name, SKU, or barcode" onChange={(e) => { setLookup(e.target.value); setPicked(null); }} />
        </Field>
        {matches.length > 0 ? (
          <ul className="mb-3 divide-y divide-line rounded-xl border border-line">
            {matches.map((p) => (
              <li key={p.id}>
                <button type="button" className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-soft" onClick={() => choose(p)}>
                  <span className="font-semibold">{p.name}</span>
                  <span className="text-muted">{p.qty} in stock · {peso(p.price)}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
        {picked ? (
          <>
            <div className="mb-3 rounded-xl bg-soft p-3 text-sm">
              <b>{picked.name}</b>
              <div className="text-muted">Available: {picked.qty} · Cost {peso(picked.cost)}</div>
            </div>
            <Field label="Quantity">
              <input className={inputCls} type="number" min="1" step="1" value={qty} onChange={(e) => setQty(e.target.value)} />
            </Field>
            <Field label="Selling price per unit (₱)">
              <input className={inputCls} type="number" min="0" step="0.01" value={unit} onChange={(e) => setUnit(e.target.value)} />
            </Field>
            <Field label="Discount (₱)">
              <input className={inputCls} type="number" min="0" step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} />
            </Field>
            <div className="mb-2 grid grid-cols-2 gap-2">
              <label className="flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold">
                <input type="radio" checked={pay === "cash"} onChange={() => setPay("cash")} /> Cash
              </label>
              <label className="flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold">
                <input type="radio" checked={pay === "credit"} onChange={() => setPay("credit")} /> Credit · 7 days
              </label>
            </div>
            {pay === "credit" ? (
              <>
                <Field label="Customer name *">
                  <input className={inputCls} value={customer} onChange={(e) => setCustomer(e.target.value)} />
                </Field>
                <Field label="Contact number">
                  <input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} />
                </Field>
              </>
            ) : null}
            <Field label="Note">
              <input className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} />
            </Field>
            <div className="rounded-xl bg-soft p-3">
              <span className="text-xs text-muted">Sale total</span>
              <strong className="block text-xl text-brand">{peso(total)}</strong>
              <span className="text-sm text-muted">Gross profit {peso(profit)}</span>
            </div>
            <div className="mt-3 flex gap-2">
              <button type="button" className="min-h-11 rounded-lg bg-brand px-4 font-bold text-white" onClick={complete}>
                Complete sale
              </button>
              <button type="button" className="min-h-11 rounded-lg bg-soft px-4 font-bold text-brand" onClick={() => { setPicked(null); setLookup(""); }}>
                Cancel
              </button>
            </div>
            {qn > picked.qty ? <p className="mt-2 text-sm text-danger">Quantity is more than stock.</p> : null}
          </>
        ) : null}
      </Card>
      <Card title="Recent sales">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-muted">
              <tr>
                <th className="py-2">When</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Pay</th>
                <th>Total</th>
                <th>Profit</th>
              </tr>
            </thead>
            <tbody>
              {data.sales.slice(0, 40).map((s) => (
                <tr key={s.id} className="border-t border-line">
                  <td className="py-2 pr-2 whitespace-nowrap">{dateLabel(s.date)}</td>
                  <td>{s.productName}</td>
                  <td>{s.qty}</td>
                  <td className="capitalize">{s.payMethod}{s.customer ? ` · ${s.customer}` : ""}</td>
                  <td>{peso(s.total)}</td>
                  <td>{peso(s.profit)}</td>
                </tr>
              ))}
              {data.sales.length === 0 ? (
                <tr><td colSpan={6} className="py-6 text-center text-muted">No sales yet.</td></tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

function CreditPanel({ data, commit }: { data: StoreData; commit: (d: StoreData, m?: string) => void }) {
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [limit, setLimit] = useState("2000");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(isoToday());
  const [due, setDue] = useState(plusDays(isoToday(), 7));
  const [payId, setPayId] = useState("");
  const [payAmt, setPayAmt] = useState("");
  const [payNote, setPayNote] = useState("");

  const active = data.credits.filter((c) => creditBalance(c) > 0);
  const outstanding = active.reduce((a, c) => a + creditBalance(c), 0);
  const dueSoon = active.filter((c) => c.due >= isoToday() && c.due <= plusDays(isoToday(), 2)).reduce((a, c) => a + creditBalance(c), 0);
  const overdue = active.filter((c) => c.due < isoToday()).reduce((a, c) => a + creditBalance(c), 0);

  function add() {
    const amt = Number(amount) || 0;
    const lim = Number(limit) || 0;
    if (!customer.trim() || amt <= 0 || lim < 0 || !due) return;
    const owed = data.credits.filter((c) => c.customer.toLowerCase() === customer.trim().toLowerCase()).reduce((a, c) => a + creditBalance(c), 0);
    if (owed + amt > lim) return;
    const rec: Credit = {
      id: uid(),
      customer: customer.trim(),
      phone: phone.trim(),
      limit: lim,
      amount: amt,
      paid: 0,
      date: date || isoToday(),
      due,
      note: note.trim() || "Credit purchase",
      payments: [],
    };
    commit({ ...data, credits: [...data.credits, rec] }, "Credit saved");
    setAmount("");
    setNote("");
  }

  function pay() {
    const c = data.credits.find((x) => x.id === payId);
    const amt = Number(payAmt) || 0;
    if (!c || amt <= 0 || amt > creditBalance(c)) return;
    const credits = data.credits.map((x) =>
      x.id === c.id
        ? { ...x, paid: Number(x.paid || 0) + amt, payments: [...(x.payments || []), { date: isoToday(), amount: amt, note: payNote.trim() }] }
        : x,
    );
    commit({ ...data, credits }, "Payment recorded");
    setPayAmt("");
    setPayNote("");
  }

  return (
    <>
      <Card title="Credit summary" hint="Customers who took goods now and pay within the due date.">
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <Stat label="Outstanding" value={peso(outstanding)} />
          <Stat label="Due in 2 days" value={peso(dueSoon)} />
          <Stat label="Overdue" value={peso(overdue)} />
        </div>
      </Card>
      <Card title="Record a credit purchase">
        <div className="grid gap-x-3 md:grid-cols-2">
          <Field label="Customer name *"><input className={inputCls} value={customer} onChange={(e) => setCustomer(e.target.value)} /></Field>
          <Field label="Phone"><input className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
          <Field label="Credit limit (₱)"><input className={inputCls} type="number" min="0" value={limit} onChange={(e) => setLimit(e.target.value)} /></Field>
          <Field label="Amount (₱) *"><input className={inputCls} type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
          <Field label="Purchase date"><input className={inputCls} type="date" value={date} onChange={(e) => { setDate(e.target.value); setDue(plusDays(e.target.value, 7)); }} /></Field>
          <Field label="Due date"><input className={inputCls} type="date" value={due} onChange={(e) => setDue(e.target.value)} /></Field>
        </div>
        <Field label="What they took"><input className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. 2 × rice, 1 × soap" /></Field>
        <button type="button" className="min-h-11 rounded-lg bg-brand px-4 font-bold text-white" onClick={add}>Save credit</button>
      </Card>
      <Card title="Record a payment">
        <Field label="Outstanding account">
          <select className={inputCls} value={payId} onChange={(e) => setPayId(e.target.value)}>
            <option value="">Choose a customer</option>
            {active.map((c) => (
              <option key={c.id} value={c.id}>{c.customer} · {peso(creditBalance(c))} · due {c.due}</option>
            ))}
          </select>
        </Field>
        <Field label="Amount paid (₱)"><input className={inputCls} type="number" min="0" step="0.01" value={payAmt} onChange={(e) => setPayAmt(e.target.value)} /></Field>
        <Field label="Note"><input className={inputCls} value={payNote} onChange={(e) => setPayNote(e.target.value)} /></Field>
        <button type="button" className="min-h-11 rounded-lg bg-brand px-4 font-bold text-white" onClick={pay}>Apply payment</button>
      </Card>
      <Card title="All credit records">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-muted">
              <tr>
                <th className="py-2">Customer</th>
                <th>Items</th>
                <th>Due</th>
                <th>Balance</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {[...data.credits].reverse().map((c) => (
                <tr key={c.id} className="border-t border-line">
                  <td className="py-2 pr-2">
                    <div className="font-semibold">{c.customer}</div>
                    {c.phone ? <div className="text-xs text-muted">{c.phone}</div> : null}
                  </td>
                  <td>{c.note}</td>
                  <td className="whitespace-nowrap">{c.due}</td>
                  <td className="font-semibold">{peso(creditBalance(c))}</td>
                  <td>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${creditStatus(c) === "OVERDUE" ? "bg-red-50 text-danger" : creditStatus(c) === "PAID" ? "bg-soft text-brand" : "bg-amber-100 text-warn"}`}>
                      {creditStatus(c)}
                    </span>
                  </td>
                </tr>
              ))}
              {data.credits.length === 0 ? (
                <tr><td colSpan={5} className="py-6 text-center text-muted">No credit yet.</td></tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

function Backup({
  data,
  commit,
  flash,
  installEvt,
  clearInstall,
  fileName,
  onSave,
  onSaveAs,
  onOpen,
}: {
  data: StoreData;
  commit: (d: StoreData, m?: string) => void;
  flash: (m: string) => void;
  installEvt: BeforeInstallPromptEvent | null;
  clearInstall: () => void;
  fileName: string;
  onSave: () => void;
  onSaveAs: () => void;
  onOpen: () => void;
}) {
  const [name, setName] = useState(data.settings.storeName);
  const [subtitle, setSubtitle] = useState(data.settings.subtitle);

  async function install() {
    if (!installEvt) return;
    await installEvt.prompt();
    const choice = await installEvt.userChoice;
    if (choice.outcome === "accepted") flash("Installed. Open it from the Start menu or home screen.");
    clearInstall();
  }

  return (
    <>
      <Card
        title="Install like a normal app"
        hint="On Windows, Chrome or Edge can install this into the Start menu and taskbar. It then opens in its own window, without the browser address bar, and keeps working offline. Phones install it to the home screen the same way. Updates arrive the next time you open the published app while online."
      >
        <div className="mb-3 flex items-start gap-3 rounded-xl bg-soft p-3">
          <img src="/icon-512.png" alt="" width={56} height={56} className="rounded-xl" />
          <div>
            <div className="font-bold">Kareth Store</div>
            <p className="text-sm text-muted">Same books on every device once you save a backup and open it there.</p>
          </div>
        </div>
        {installEvt ? (
          <button type="button" className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-accent px-4 font-bold text-white" onClick={install}>
            <MonitorDown size={18} /> Install this app
          </button>
        ) : (
          <ol className="list-decimal space-y-2 pl-5 text-sm leading-relaxed text-ink">
            <li><b>Windows:</b> Chrome or Edge → install icon in the address bar, or menu → Install app / Apps → Install this site as an app. It then shows in the Start menu like other software.</li>
            <li><b>Android:</b> Chrome menu → Install app or Add to Home screen.</li>
            <li><b>iPhone / iPad:</b> Safari → Share → Add to Home Screen.</li>
            <li><b>Mac:</b> Chrome or Edge menu → Install Kareth Store.</li>
          </ol>
        )}
      </Card>
      <Card
        title="Save as a file"
        hint={
          fileName
            ? `This window is linked to ${fileName}. Save writes that same file. Save as… picks a new place (USB, Documents, Desktop). Open replaces the books on this device with another file.`
            : "Choose Save as… to put the store on your computer like any other document. On Windows (Chrome or Edge) you pick the folder. On phones it downloads a file you can share. Opening a file replaces the data on that device."
        }
      >
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-brand px-4 font-bold text-white"
            onClick={onSave}
          >
            <Download size={18} /> Save
          </button>
          <button
            type="button"
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-accent px-4 font-bold text-white"
            onClick={onSaveAs}
          >
            <Download size={18} /> Save as…
          </button>
          <button
            type="button"
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-soft px-4 font-bold text-brand"
            onClick={onOpen}
          >
            <FolderOpen size={18} /> Open…
          </button>
        </div>
        <p className="mt-3 flex items-center gap-2 text-sm text-muted">
          <ClipboardList size={16} /> {data.products.length} products · {data.sales.length} sales · {data.credits.length} credit records
        </p>
      </Card>
      <Card title="Store name on this device">
        <Field label="Name shown in the header">
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Subtitle">
          <input className={inputCls} value={subtitle} onChange={(e) => setSubtitle(e.target.value)} />
        </Field>
        <button
          type="button"
          className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-brand px-4 font-bold text-white"
          onClick={() => commit({ ...data, settings: { storeName: name.trim() || data.settings.storeName, subtitle: subtitle.trim() } }, "Settings saved")}
        >
          <Settings2 size={18} /> Save settings
        </button>
      </Card>
    </>
  );
}
